package Game;

public enum Status {
    TURN,
    WAITING,
    WIN,
    LOSE,
    TIE,
    PROMPT,
    PLAYAGAIN,
    END,
    RESPONSE
}